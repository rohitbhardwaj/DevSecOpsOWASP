/*jshint multistr:true */

(function(ibmcode, undefined){

	//public methods
	ibmcode.$ = function(selector){
		return document.querySelectorAll(selector);
	};
	ibmcode.addEvent = function(el, type, handler) {
		if(el.attachEvent){
			el.attachEvent('on'+type, handler);
		}else{
			el.addEventListener(type, handler);
		}
	};
	ibmcode.removeEvent = function(el, type, handler) {
		if(el.detachEvent){
			el.detachEvent('on'+type, handler);
		}else{
		 el.removeEventListener(type, handler);
		}
	};

	ibmcode.setModalIframeHeight = function() {
		var iframe = document.getElementById('challengeIframe');
		if(iframe){
			setTimeout(function(){
				console.info('resizing');
				var iframeWin = iframe.contentWindow || iframe.contentDocument.parentWindow;
				var iframeWrap = document.querySelector('.challenge--modal-content');
				iframeWrap.style.height = 'auto';
				ifHeight = Math.max(iframeWin.document.documentElement.scrollHeight,iframeWin.document.body.scrollHeight);
				iframeWrap.style.height = ifHeight + 'px';
			},500)
		}
	};

	//Notifications
	/*
		{
			"type": info (default),error,success,warning - [string]
			"title": "Title of notification" - [string][required]
			"subtitle": "Subitle of notification" - [string]
			"caption": "timestamp" - [string]
			"duration" [int]
		}
	*/
	ibmcode.addNotification = function(opts){
		if(typeof opts != 'object' || !opts.title){
			return;
		}
		switch(opts.type){
			case 'undefined':
			case 'info':
				klass = 'bx--toast-notification--info';
				ikon = '<svg focusable="false" preserveAspectRatio="xMidYMid meet" style="will-change: transform;" xmlns="http://www.w3.org/2000/svg" class="bx--toast-notification__icon" width="20" height="20" viewBox="0 0 32 32" aria-hidden="true"><path d="M16,2A14,14,0,1,0,30,16,14,14,0,0,0,16,2Zm0,5a1.5,1.5,0,1,1-1.5,1.5A1.5,1.5,0,0,1,16,7Zm4,17.12H12V21.88h2.88V15.12H13V12.88h4.13v9H20Z"></path></svg>';
			break;
			case 'error':
				klass = 'bx--toast-notification--error';
				ikon = '<svg focusable="false" preserveAspectRatio="xMidYMid meet" style="will-change: transform;" xmlns="http://www.w3.org/2000/svg" class="bx--toast-notification__icon" width="20" height="20" viewBox="0 0 20 20" aria-hidden="true"><path d="M10,1c-5,0-9,4-9,9s4,9,9,9s9-4,9-9S15,1,10,1z M13.5,14.5l-8-8l1-1l8,8L13.5,14.5z"></path><path d="M13.5,14.5l-8-8l1-1l8,8L13.5,14.5z" data-icon-path="inner-path" opacity="0"></path></svg>';
			break;
			case 'success':
				klass = 'bx--toast-notification--success';
				ikon = '<svg focusable="false" preserveAspectRatio="xMidYMid meet" style="will-change: transform;" xmlns="http://www.w3.org/2000/svg" class="bx--toast-notification__icon" width="20" height="20" viewBox="0 0 20 20" aria-hidden="true"><path d="M10,1c-4.9,0-9,4.1-9,9s4.1,9,9,9s9-4,9-9S15,1,10,1z M8.7,13.5l-3.2-3.2l1-1l2.2,2.2l4.8-4.8l1,1L8.7,13.5z"></path><path fill="none" d="M8.7,13.5l-3.2-3.2l1-1l2.2,2.2l4.8-4.8l1,1L8.7,13.5z" data-icon-path="inner-path" opacity="0"></path></svg>';
			break;
			case 'warning':
				klass = 'bx--toast-notification--warning';
				ikon = '<svg focusable="false" preserveAspectRatio="xMidYMid meet" style="will-change: transform;" xmlns="http://www.w3.org/2000/svg" class="bx--toast-notification__icon" width="20" height="20" viewBox="0 0 20 20" aria-hidden="true"><path d="M10,1c-5,0-9,4-9,9s4,9,9,9s9-4,9-9S15,1,10,1z M9.2,5h1.5v7H9.2V5z M10,16c-0.6,0-1-0.4-1-1s0.4-1,1-1	s1,0.4,1,1S10.6,16,10,16z"></path><path d="M9.2,5h1.5v7H9.2V5z M10,16c-0.6,0-1-0.4-1-1s0.4-1,1-1s1,0.4,1,1S10.6,16,10,16z" data-icon-path="inner-path" opacity="0"></path></svg>';
			break;
			default:
				klass = 'bx--toast-notification--info';
				ikon = '<svg focusable="false" preserveAspectRatio="xMidYMid meet" style="will-change: transform;" xmlns="http://www.w3.org/2000/svg" class="bx--toast-notification__icon" width="20" height="20" viewBox="0 0 32 32" aria-hidden="true"><path d="M16,2A14,14,0,1,0,30,16,14,14,0,0,0,16,2Zm0,5a1.5,1.5,0,1,1-1.5,1.5A1.5,1.5,0,0,1,16,7Zm4,17.12H12V21.88h2.88V15.12H13V12.88h4.13v9H20Z"></path></svg>';
		}

		var title = '<h3 class="bx--toast-notification__title">'+opts.title+'</h3>';

		if(opts.subtitle){
			var subtitle = '<p class="bx--toast-notification__subtitle">'+opts.subtitle+'</p>';
		}else{
			var subtitle = '';
		}
		if(opts.caption){
			var caption = '<p class="bx--toast-notification__caption">'+opts.caption+'</p>';
		}else{
			var caption = '';
		}


			var notificationBody = ikon;
					notificationBody += '<div class="bx--toast-notification__details">'+title+subtitle+caption+'</div>\
				  <button data-notification-btn class="bx--toast-notification__close-button" type="button" aria-label="close">\
				    <svg focusable="false" preserveAspectRatio="xMidYMid meet" style="will-change: transform;" xmlns="http://www.w3.org/2000/svg" class="bx--toast-notification__close-icon" width="20" height="20" viewBox="0 0 32 32" aria-hidden="true"><path d="M24 9.4L22.6 8 16 14.6 9.4 8 8 9.4 14.6 16 8 22.6 9.4 24 16 17.4 22.6 24 24 22.6 17.4 16 24 9.4z"></path></svg>\
				  </button>';
			var notification = document.createElement('div');
					notification.setAttribute('data-notification','');
					notification.setAttribute('class','bx--toast-notification '+klass+' bx--toast-notification--low-contrast');
					notification.setAttribute('role','alert');
					notification.innerHTML = notificationBody;
			document.getElementById('notificationDrawer').appendChild(notification);
			if(opts.duration && typeof opts.duration === "number"){
				setTimeout(
					function(){
						notification.querySelector('button.bx--toast-notification__close-button').click();
					},
					(parseInt(opts.duration)*1000)
				);
			}

		}


	ibmcode.copyText = function(element) {
  var range, selection, worked;

  if (document.body.createTextRange) {
    range = document.body.createTextRange();
    range.moveToElementText(element);
    range.select();
  } else if (window.getSelection) {
    selection = window.getSelection();
    range = document.createRange();
    range.selectNodeContents(element);
    selection.removeAllRanges();
    selection.addRange(range);
  }

  try {
    document.execCommand('copy');
  }
  catch (err) {
    alert('unable to copy text');
  }
}


	ibmcode.getClosest = function (elem, selector) {
	  // Element.matches() polyfill
		if (!Element.prototype.matches) {
		    Element.prototype.matches =
		        Element.prototype.matchesSelector ||
		        Element.prototype.mozMatchesSelector ||
		        Element.prototype.msMatchesSelector ||
		        Element.prototype.oMatchesSelector ||
		        Element.prototype.webkitMatchesSelector ||
		        function(s) {
		            var matches = (this.document || this.ownerDocument).querySelectorAll(s),
		                i = matches.length;
		            while (--i >= 0 && matches.item(i) !== this) {}
		            return i > -1;
		        };
		}
		for ( ; elem && elem !== document; elem = elem.parentNode ) {
			if( elem.matches( selector ) ){
				return elem;
			}
		}
		return null;
	};

	ibmcode.widgetSetSameHeight = function($collection,resizing){
      [].forEach.call( $collection, function(el) {
        var $children = el.querySelectorAll(el.dataset.items);
        var $maxHeight = 0;
        [].forEach.call( $children, function(el) {
          if(resizing && resizing === true){
            el.style.height = 'auto';
          }
					if(el.offsetHeight > $maxHeight){
						$maxHeight = el.offsetHeight;
					}
        });
        //now go back through the elements and set their heights
        [].forEach.call( $children, function(el) {
          el.style.height = $maxHeight+'px';
        });
      });
    };

		ibmcode.getAjax = function(url, callback) {
	    var xhr = window.XMLHttpRequest ? new XMLHttpRequest() : new ActiveXObject('Microsoft.XMLHTTP');
	    xhr.open('GET', url);
	    xhr.onreadystatechange = function() {
	    	if (xhr.readyState > 3 && xhr.status === 200 && typeof callback === "function"){
					callback(xhr.responseText);
				}
	    };
	    xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
	    xhr.send();
	    return xhr;
		};
		ibmcode.postAjax = function(url, data, callback) {
			var params;
			if( typeof data === 'string' ){
				params = data;
			}else{
				params = Object.keys(data).map( function(k){
					return encodeURIComponent(k) + '=' + encodeURIComponent(data[k]);
				}).join('&');
			}
	    var xhr = window.XMLHttpRequest ? new XMLHttpRequest() : new ActiveXObject("Microsoft.XMLHTTP");
	    xhr.open('POST', url);
	    xhr.onreadystatechange = function() {
	        if (xhr.readyState > 3 && xhr.status === 200){
						callback(xhr.responseText);
					}
	    };
	    xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
	    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
	    xhr.send(params);
	    return xhr;
		};
		ibmcode.deleteAjax = function(url, data, callback) {
			var params;
			if( typeof data === 'string' ){
				params = data;
			}else{
				params = Object.keys(data).map( function(k){
					return encodeURIComponent(k) + '=' + encodeURIComponent(data[k]);
				}).join('&');
			}
	    var xhr = window.XMLHttpRequest ? new XMLHttpRequest() : new ActiveXObject("Microsoft.XMLHTTP");
	    xhr.open('DELETE', url);
	    xhr.onreadystatechange = function() {
	        if (xhr.readyState > 3 && xhr.status === 200){
						callback(xhr.responseText);
					}
	    };
	    xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
	    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
	    xhr.send(params);
	    return xhr;
		};

		ibmcode.xhrJSON = function(url, data, callback, method) {
			method = typeof method !== 'undefined' ? method : 'POST';
			if(method === "GET"){
				params = Object.keys(data).map(key => key + '=' + data[key]).join('&');
				url += "?" + params;
			}
			var xhr = window.XMLHttpRequest ? new XMLHttpRequest() : new ActiveXObject("Microsoft.XMLHTTP");
			xhr.open(method, url, true);
			xhr.onreadystatechange = function () {
				if (xhr.readyState > 3 && xhr.status === 200){
					callback(xhr.responseText);
				}
			}
			xhr.setRequestHeader("Content-type", "application/json");
			if(method === "GET"){
				xhr.send();
			}else{
				data = JSON.stringify(data);
				xhr.send(data);
			}

		}

		ibmcode.postJSON = function(url, data, callback) {
			var xhr = window.XMLHttpRequest ? new XMLHttpRequest() : new ActiveXObject("Microsoft.XMLHTTP");
			xhr.open("POST", url, true);
			xhr.onreadystatechange = function () {
				if (xhr.readyState > 3 && xhr.status === 200){
					callback(xhr.responseText);
				}
			}
			xhr.setRequestHeader("Content-type", "application/json");
			data = JSON.stringify(data);
			xhr.send(data);
		}

		ibmcode.socialpopup = function(event,elm) {
			event.preventDefault();
			if(elm.getAttribute('data-id') === 'qrcode'){
				var body = document.createElement('div');
				body.setAttribute("style", "width:256px;height:256px;position:absolute;margin:auto;padding:0;left: 50%;margin-left: -128px;top: 50%;margin-top: -128px;");
				var qrcode = new QRCode(body, {
            text: elm.href,
            width: 256,
            height: 256,
            colorDark: "#ffffff",
            colorLight: "#333333",
            correctLevel: QRCode.CorrectLevel.H
        });
				var winpops = window.open('', '', 'width=600,height=600,status,scrollbars,resizable');
				// winpops.document.write("this is a test");
				winpops.document.body.setAttribute("style", "margin:0;padding:0;background:#282828;");
				winpops.document.body.appendChild(body);
				winpops.document.close(); // needed for chrome and safari
			}else{
				var winpops=window.open(elm.href,"","width=800,height=600,status,scrollbars,resizable");
			}
		};

		ibmcode.setCookie = function(name,value,days) {
	    var expires = "";
	    if (days) {
	        var date = new Date();
	        date.setTime(date.getTime() + (days*24*60*60*1000));
	        expires = "; expires=" + date.toUTCString();
	    };
	    document.cookie = name + "=" + (value || "")  + expires + "; path=/";
		};

		ibmcode.getCookie = function(name) {
	    var nameEQ = name + "=";
	    var ca = document.cookie.split(';');
	    for(var i=0;i < ca.length;i++) {
	        var c = ca[i];
	        while (c.charAt(0)==' ') c = c.substring(1,c.length);
	        if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length,c.length);
	    }
	    return null;
		};

		ibmcode.eraseCookie = function(name) {
    	document.cookie = name+'=; Max-Age=-99999999;' + " path=/";
		};

}(window.ibmcode = window.ibmcode || {}));
